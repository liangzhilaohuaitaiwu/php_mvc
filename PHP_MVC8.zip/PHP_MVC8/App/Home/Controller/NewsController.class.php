<?php
//对类UserController进行保护
final class NewsController extends BaseController{
    //创建函数index
    public function index(){
        $modelObj = FactoryModel::geInstance("NewsModel");
        $arrs = $modelObj -> fetchAll();
        $count = $modelObj -> rowCount();
        include "./App/Home/View/News/index.html";
        //显示表格news的数据
    }

    //创建函数edit
    public function detail()
    {
        $id = $_GET["id"];
        $modelObj = FactoryModel::geInstance("NewsModel");
        $arr = $modelObj -> fetchOne($id);

        include "./App/Home/View/News/detail.html";
    }
    //跳转至页面UserEditView

}



