<?php

//对类UserController进行保护
final class UserController extends BaseController
{
    //创建函数index
    public function index()
    {
        $modelObj = FactoryModel::geInstance("UserModel");
        $arrs = $modelObj -> fetchAll();
        $count = $modelObj -> rowCount();
        include "./App/Home/View/User/index.html";
        //显示表格users的数据
    }
}


