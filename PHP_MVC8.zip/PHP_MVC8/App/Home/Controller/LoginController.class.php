<?php
class LoginController extends BaseController
{
    public function index(){
        include VIEW_PATH."index.html";
    }

    public function check()
    {
        $modelObj = FactoryModel::geInstance("LoginModel");
        $data["uname"] = $_POST["uname"];
        $data["upass"] = md5($_POST["upass"]);
        $result = $modelObj->check($data);
        $useryzm=$_POST['useryzm'];
        $yzmchar = $_SESSION['string'];
        if (strtoupper($useryzm) == strtoupper($yzmchar))
        {
            if (isset($result))
            {
                $_SESSION["uname"] = $result["uname"];
                $_SESSION["is_admin"] = $result["is_admin"];
                if ($_SESSION["is_admin"])
                {
                    $this->jump("登录成功，正在跳转！", 1, "?p=Home&c=News");
                }
            } else {
                $this->jump("用户名或密码错误，请重新登录！", 1, "?p=Home&c=Login");
            }
        }else{
            $this->jump("<script>alert('验证码输入错误，请重新输入')</script>", 1, "?p=Home&c=Login");
//            echo "<script>";
//            echo "document.getElementById('useryzm').placeholder='验证码输入错误，请重新输入';";
//            echo "document.getElementById('useryzm').className='inp';";
//            echo "</script>";
//            header("refresh:3,url=?p=Admin&c=Login");
        }
    }

    public function logout()
    {
        unset($_SESSION["uname"]);
        unset($_SESSION["is_admin"]);
        $this -> jump("用户已退出！",1,"?p=Admin&c=Login");
    }

}