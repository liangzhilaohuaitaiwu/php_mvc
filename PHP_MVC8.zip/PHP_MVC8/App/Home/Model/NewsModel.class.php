<?php
//定义类NewsModel
class NewsModel extends BaseModel
{
    //建立通用方法fetchAll
    public function fetchAll(){
        $sql = "select * from news order by nid ";
        return $this -> db -> fetchAll($sql);
    }
    //显示数据库中的数据，表格为news
    //定义通用方法delete
    public function delete($id){
        $sql = "delete from news where nid={$id}";
        return $this -> db -> exec($sql);
    }
    //删除表格news的数据
    //定义通用方法insert
    public function insert($data){
        $fields = "";
        $values = "";
        foreach ($data as $key => $value){
            $fields.="{$key},";
            $values.="'{$value}',";
        }
        $fields = rtrim($fields,",");
        $values = rtrim($values,",");
        //将数据最后的","去除
        $sql = "insert into news($fields) values($values)";
        return $this -> db ->exec($sql);
    }
    //将数据插入到news表格中
    //将从NewsAddView传来的数据插入到数据库中

    //定义通用方法fetchOne
    //显示数据库中的数据，表格为news
    public function fetchOne($id)
    {
        $sql = "select * from news where nid={$id}";
        return $this -> db -> fetchOne($sql);
    }

    //定义通用方法update
    public function update($id,$data)
    {
        $str = "";
        foreach ($data as $key => $value)
        {
            $str .= "{$key}='{$value}',";
        }
        $str = rtrim($str, ",");
        $sql = "update `news` set {$str} where nid={$id}";
        return $this -> db -> exec($sql);
    }
    //更新数据库中的数据

    //定义通用方法fetchAll
    public function rowCount()
    {
        $sql = "select * from news order by nid";
        return $this -> db -> rowCount($sql);
    }
}


