<?php
	session_start();
	$num1=range(0,9);//'0123456789'
	$char=range('A','Z');
    $char1=range('a','z');
	$res=array_merge($num1,$char,$char1);
	$len=count($res);//36
	$string='';
	for($i=0;$i<4;$i++){
		$ind=rand(0,$len-1);
		$string=$string.$res[$ind];
	}
	$_SESSION['string']=$string;
	//echo $string;
	header("content-type:image/png");
	$w=150;
	$h=35;
	// 创建一个$w行$h列的图像
    $img=imagecreatetruecolor($w,$h);
	$white=imagecolorallocate($img,255,255,255);
	$black=imagecolorallocate($img,0,0,0);
//	imagefill($img,0,0,$white);
	for($i=1;$i<=50;$i++){
		imagesetpixel($img,rand(0,$w-1),rand(0,$h-1),$white);
	}
	for($i=0;$i<1;$i++){
		imageline($img,rand(0,$w-1),rand(0,$h-1),
		rand(0,$w-1),rand(0,$h-1),$white);
	}
	$fontfile=realpath('times.ttf');
	for($i=0;$i<4;$i++){
		$x=$w/4*$i+8;
		$y=rand(16,19);
		$color=imagecolorallocate($img,rand(50,150),rand(50,150),rand(100,150));
		$angle=rand(-45,45);
		imagettftext($img, 14, $angle, $x, $y, $color, $fontfile, $string[$i]);
	}
	imagepng($img);
	imagedestroy($img);
?>