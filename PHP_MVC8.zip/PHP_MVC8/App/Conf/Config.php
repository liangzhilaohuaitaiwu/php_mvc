<?php
$arr = array(
    //数据库配置信息
    "db_host" => "127.0.0.1",
    "db_user" => "newsweb",
    "db_pass" => "password",
    "db_name" => "NewsWeb",
    "charset" => "utf-8",

    //默认路由参数
    "default_platform" => "Home",
    "default_controller" => "News",
    "default_action" => "index",
);
return $arr;