<?php
//对类UserController进行保护
final class NewsController extends BaseController
{
    //创建函数delete
    public function delete(){
        if($_SESSION["is_admin"] == 0){
            $id = $_GET["id"];
            $modelObj = FactoryModel::geInstance("NewsModel");
            //调用类FactoryModel
            if($modelObj -> delete($id)){
                $this -> jump("删除id={$id}记录成功!",1,"?p=Admin&c=News");
            }else{
                $this -> jump("删除id={$id}记录失败!",1,"?p=Admin&c=News");
            }
            //对表格news的数据进行删除
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }

    }

    //创建函数index
    public function index()
    {
        if($_SESSION["is_admin"] == 0)
        {
            $modelObj = FactoryModel::geInstance("NewsModel");
            $arrs = $modelObj -> fetchAll();
            $count = $modelObj -> rowCount();
            include VIEW_PATH."index.html";
            //显示表格news的数据
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }
    }

    //创建函数add
    public function add(){
        if($_SESSION["is_admin"] == 0)
        {
            include VIEW_PATH."add.html";
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }
    }
    //跳转至页面NewsAddView
    //创建函数insert
    public function insert(){
        if($_SESSION["is_admin"] == 0)
        {
            $data["title"] = $_POST["title"];
            $data["content"] = $_POST["content"];
            $data["release_time"] = Date("Y-m-d H:i:s");
            $data["editor"] = ($_POST["editor"]);
            $modelObj = FactoryModel::geInstance("NewsModel");
            if($modelObj -> insert($data)){
                $this -> jump("添加新闻成功!",1,"?p=Admin&c=News");
            }else{
                $this -> jump("添加失败成功!",1,"?p=Admin&c=News");
            }
            //获取表单数据
            //调用类FactoryModel
            //调用类NewsModel的insert方法
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }
    }

    //创建函数edit
    public function edit()
    {
        if($_SESSION["is_admin"] == 0)
        {
            $id = $_GET["id"];
            $modelObj = FactoryModel::geInstance("NewsModel");
            $arr = $modelObj -> fetchOne($id);
            include VIEW_PATH."edit.html";
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }
    }
    //跳转至页面UserEditView
    //创建函数update
    public function update()
    {
        if($_SESSION["is_admin"] == 0)
        {
            $id = $_POST["nid"];
            $data["title"] = $_POST["title"];
            $data["content"] = $_POST["content"];
            $data["release_time"] = Date("Y-m-d H:i:s");
            $data["editor"] = ($_POST["editor"]);
            if($_POST["old_title"] != $_POST["title"])
            {
                $data["title"] = $_POST["title"];
            }
            if($_POST["old_content"] != $_POST["content"])
            {
                $data["content"] = $_POST["content"];
            }
            $modelObj = FactoryModel::geInstance("NewsModel");
            if($modelObj -> update($id,$data)){
                $this -> jump("修改新闻成功!",1,"?p=Admin&c=News");
            }else{
                $this -> jump("修改新闻失败!",1,"?p=Admin&c=News");
            }
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=News");
        }
    }

}



