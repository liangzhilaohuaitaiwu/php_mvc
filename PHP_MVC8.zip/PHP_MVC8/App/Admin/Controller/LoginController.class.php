<?php
class LoginController extends BaseController
{
    public function index(){
        include VIEW_PATH."index.html";
    }

   public function check()
    {
        //实例化一个LoginModel模型
        $modelObj = FactoryModel::geInstance("LoginModel");
        //获取表单中的用户名和密码
        $data["uname"] = $_POST["uname"];
        //将密码进行md5加密
        $data["upass"] = md5($_POST["upass"]);
        //调用模型的check方法，传入data参数，获取返回结果
        $result = $modelObj->check($data);
        //获取表单中的验证码
        $useryzm=$_POST['useryzm'];
        //获取session中的验证码
        $yzmchar = $_SESSION['string'];
        //判断用户输入的验证码是否正确
        if (strtoupper($useryzm) == strtoupper($yzmchar))
        {
            //判断返回结果是否为空
            if (isset($result))
            {
                //将用户名和密码存入session
                $_SESSION["uname"] = $result["uname"];
                //将是否为管理员存入session
                $_SESSION["is_admin"] = $result["is_admin"];
                //判断是否为普通用户
                if ($_SESSION["is_admin"] === '0')
                {
                    //跳转到管理员页面
                    $this->jump("登录成功，正在跳转！", 1, "?p=Admin&c=News");
                } else if ($_SESSION["is_admin"] === '1') {
                    //跳转到管理员页面
                    $this->jump("登录成功，正在跳转！", 1, "?p=Admin&c=User");
                }
            } else {
                //跳转到登录页面
                $this->jump("用户名或密码错误，请重新登录！", 1, "?p=Admin&c=Login");
            }
        }else{
            //跳转到登录页面
            $this->jump("<script>alert('验证码输入错误，请重新输入')</script>", 1, "?p=Admin&c=Login");
        }
    }

   public function logout()
    {
        // 销毁session中的uname和is_admin
        unset($_SESSION["uname"]);
        unset($_SESSION["is_admin"]);
        // 跳转到登录页面
        $this -> jump("用户已退出！",1,"?p=Admin&c=Login");
    }
}