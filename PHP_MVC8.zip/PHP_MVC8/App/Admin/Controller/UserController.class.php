<?php

//对类UserController进行保护
final class UserController extends BaseController
{
    //创建函数delete
    public function delete()
    {
        if($_SESSION["is_admin"] == 1)
        {
            $id = $_GET["id"];
            $modelObj = FactoryModel::geInstance("UserModel");
            //调用类FactoryModel
            if($modelObj -> delete($id))
            {
                $this -> jump("删除id={$id}记录成功!",1,"?p=Admin&c=User");
            }else{
                $this -> jump("删除id={$id}记录失败!",1,"?p=Admin&c=User");
            }
            //对表格users的数据进行删除
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");
        }
    }
    //创建函数index
    public function index()
    {
        if($_SESSION["is_admin"] == 1)
        {
            $modelObj = FactoryModel::geInstance("UserModel");
            $arrs = $modelObj -> fetchAll();
            $count = $modelObj -> rowCount();
            include VIEW_PATH."index.html";
            //显示表格news的数据
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");
        }
    }

    //创建函数add
    public function add()
    {
        if($_SESSION["is_admin"] == 1)
        {
            include VIEW_PATH."add.html";
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");
        }
    }
    //跳转至页面UserAddView
    //创建函数insert
    public function insert()
    {
        if($_SESSION["is_admin"] == 1)
        {
            $data["uname"] = $_POST["uname"];
            $data["is_admin"] = $_POST["is_admin"];
            $data["upass"] = MD5($_POST["upass"]);
            $modelObj = FactoryModel::geInstance("UserModel");
            if($modelObj -> insert($data)){
                $this -> jump("添加用户成功!",1,"?p=Admin&c=User");
            }else{
                $this -> jump("添加用户失败!",1,"?p=Admin&c=User");
            }
            //获取表单提交的数据
            //调用类FactoryModel
            //调用类UserModel中的insert方法
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");

        }
    }
    //创建函数edit
    public function edit()
    {
        if($_SESSION["is_admin"] == 1)
        {
            $id = $_GET["id"];
            $modelObj = FactoryModel::geInstance("UserModel");
            $arr = $modelObj -> fetchOne($id);
            include VIEW_PATH."edit.html";
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");
        }
    }
    //跳转至页面UserEditView
    //创建函数update
    public function update()
    {
        if($_SESSION["is_admin"] == 1)
        {
            $id = $_POST["uid"];
            $data["uname"] = $_POST["uname"];
            $data["is_admin"] = $_POST["is_admin"];
            if($_POST["old_upass"] != $_POST["upass"])
            {
                $data["upass"] = MD5($_POST["upass"]);
            }
            $modelObj = FactoryModel::geInstance("UserModel");
            if($modelObj -> update($id,$data)){
                $this -> jump("修改用户成功!",1,"?p=Admin&c=User");
            }else{
                $this -> jump("修改用户失败!",1,"?p=Admin&c=User");
            }
        }else{
            $this -> jump("无权限！",1,"?p=Admin&c=User");
        }
    }

}


