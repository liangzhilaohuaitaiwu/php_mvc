<?php

class LoginModel extends BaseModel
{
    public function check($data)
    {
        $str ="";
        foreach ($data as $key =>$value)
        {
            $str.="{$key}='{$value}' and ";
        }
        $str=rtrim($str," and ");
        $sql = "select * from users where {$str}";
        return $this -> db -> fetchOne($sql);
    }
}