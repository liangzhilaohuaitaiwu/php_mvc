<?php
require_once ("./Frame/Frame.class.php");
// 加载Frame类
Frame::run();
