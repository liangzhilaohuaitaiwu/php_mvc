<?php

class Db
{
    private $db_host;

    private $db_user;

    private $db_pass;

    private $db_name;

    private $charset;

    private $conn;

    public $res;

    private static $obj=null;

    private function __construct()
    {
        $this->db_host = $GLOBALS['config']["db_host"];
        $this->db_user = $GLOBALS['config']["db_user"];
        $this->db_pass = $GLOBALS['config']["db_pass"];
        $this->db_name = $GLOBALS['config']["db_name"];
        $this->charset = $GLOBALS['config']["charset"];
        $this->connectDb();
        $this->selectDb();
        $this->setCharset();
//        $this->creatDb();
//        $this->creatTab();
    }

    public function __destruct()
    {
        mysqli_close($this->conn);
    }

    private function connectDb()
    {
        if (!$this->conn = @mysqli_connect($this->db_host, $this->db_user, $this->db_pass))
        {
            echo "连接数据库失败<br>";
            die();
        }

        //加@符号是为了提高数据的安全性，防止黑客进入内网后查看到数据库的IP
    }

    private function selectDb()
    {
        if (!mysqli_select_db($this->conn, $this->db_name))
        {
            echo "选择数据库失败<br>";
            die();
        }
    }

    private function setCharset()
    {
        mysqli_set_charset($this->conn, $this->charset);
    }

    private function __clone()
    {
        // TODO:Implement __clone() method.
    }

    public static function getINstance()
    {
        if(!self::$obj instanceof self)
        {
            self::$obj = new self();
        }
        return self::$obj;
    }

    //执行成功返回true,执行失败返回false,增、删、改
    public function exec($sql)
    {
        $sql=strtolower($sql);
        //将SQL语言全部替换为小写
        if(substr($sql,0,6)=="select")
        {
            echo "不能执行select语句！";
            die();
        }
        return mysqli_query($this->conn,$sql);
    }
    //执行成功则返回结果,执行失败则返回flase.查询
    //获取结果集

    private function query($sql)
    {
        $sql=strtolower($sql);
        //将SQL语言全部替换为小写
        if(substr($sql,0,6)!="select")
        {
            echo "不能执行非select语句！";
            die();
        }
        return mysqli_query($this->conn,$sql);
    }

    //获取单条记录
    public function fetchOne($sql,$type=3)
    {
        $result=$this->query($sql);
        $type =array(
            1 => MYSQLI_NUM,
            2 => MYSQLI_BOTH,
            3 => MYSQLI_ASSOC,
            );
        return mysqli_fetch_array($result,MYSQLI_ASSOC);
    }

    //获取多条数据
    public function fetchAll($sql,$type=3)
    {
        $result=$this->query($sql);
        $type =array(
            1 => MYSQLI_NUM,
            2 => MYSQLI_BOTH,
            3 => MYSQLI_ASSOC,
        );
        return mysqli_fetch_all($result,MYSQLI_ASSOC);
    }

    //获取所有有的记录数
    public function rowCount($sql)
    {
        $result=$this->query($sql);
        return mysqli_num_rows($result);
    }

}


//$db_arr = array
//(
//    "db_host" => "127.0.0.1",
//    "db_user" => "newsweb",
//    "db_pass" => "password",
//    "db_name" => "NewsWeb",
//    "charset" => "utf-8"
//);
//
//$db1 = Db::getINstance($db_arr);
//var_dump($db1);


//$db2=new Db($db_arr);
//var_dump($db2);