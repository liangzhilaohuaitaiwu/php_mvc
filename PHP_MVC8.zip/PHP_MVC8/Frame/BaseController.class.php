<?php
session_start();
// 父类
abstract class BaseController{
    // 跳转方法
    // $message 提示信息
    // $second 跳转时间
    // $url 跳转地址
    protected function jump($message,$second=1,$url="?"){
        echo "<h2>$message</h2>";
        header("refresh:{$second},url={$url}");
        die();
    }
}

