<?php
//定义一个抽象类
//抽象类不能被实例化，只能被继承
abstract class BaseModel{
    //对属性$db进行保护
    protected $db = null;
    //将fetchAll和两个delete两个方法共有的部分提取出来使用构造方法减少代码冗余
    public function __construct(){
        $this -> db = Db::getINstance();
    }
}