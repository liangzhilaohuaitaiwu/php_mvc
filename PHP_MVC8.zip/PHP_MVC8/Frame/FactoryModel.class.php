<?php

//连接两个Mode文件，加上final防止被覆盖和继承
final class FactoryModel{
    public static function geInstance($modelClassName){
        return new $modelClassName();
    }
}
//增加类FactoryModel用来帮助两个Controller文件中的$modelObj进行替换