<?php

final class Frame
{
    public static function run()
    {
        self::initConfig();//初始化配置信息
        self::initRoute();//初始化路由参数
        self::initConst();//初始化目录常量
        self::initAutoLoad();//初始化类的自动加载
        self::initDispatch();//初始化请求分发

    }

    private static function initConfig()
    {
        // 加载配置文件
        $GLOBALS["config"]=require_once ("./App/Conf/Config.php");
    }

    private static function initRoute()
    {
        //获取URL中的参数p，如果没有则默认为$GLOBALS
        $p = isset($_GET["p"])?$_GET["p"]:$GLOBALS['config']["default_platform"];
        //获取URL中的参数c，如果没有则默认为News
        $c = isset($_GET["c"])?$_GET["c"]:$GLOBALS['config']["default_controller"];
        //获取URL中的参数a，如果没有则默认为index
        $a = isset($_GET["a"])?$_GET["a"]:$GLOBALS['config']["default_action"];
        // 定义一个函数，用于获取URL中的参数
        // 参数：$p：平台；$c：控制器；$a：操作
        define("PLAT",$p);
        define("CONTROLLER",$c);
        define("ACTION",$a);
    }

    private static function initConst()
    {
        //定义DS常量，用于表示文件分隔符
        define("DS",DIRECTORY_SEPARATOR);
        //定义ROOT_PATH常量，用于表示当前文件夹的路径
        define("ROOT_PATH",getcwd().DS);
        //定义FRAME_PATH常量，用于表示Frame文件夹的路径
        define("FRAME_PATH",ROOT_PATH."Frame".DS);
        //定义MODEL_PATH常量，用于表示Model文件夹的路径
        define("MODEL_PATH",ROOT_PATH."App".DS.PLAT.DS."Model".DS);
        //定义CONTROLLER_PATH常量，用于表示Controller文件夹的路径
        define("CONTROLLER_PATH",ROOT_PATH."App".DS.PLAT.DS."Controller".DS);
        //定义VIEW_PATH常量，用于表示View文件夹的路径
        define("VIEW_PATH",ROOT_PATH."App".DS.PLAT.DS."View".DS.CONTROLLER.DS);
    }

    private static function initAutoLoad()
    {
        spl_autoload_register(function ($className)
        {
            // 定义一个数组，存放类文件路径
            $arr = array(
            FRAME_PATH.$className.".class.php",
            MODEL_PATH.$className.".class.php",
            CONTROLLER_PATH.$className.".class.php"
            );
            // 遍历数组，判断类文件是否存在
            foreach ($arr as $filename) {
                if (file_exists($filename)){
                    // 如果存在，则加载类文件
                    require_once($filename);
                }
            }
        }
        );
    }

    private static function initDispatch()
    {
        $controllerObjClassName = CONTROLLER."Controller";
        // 创建一个新的控制器对象
        $controllerObj = new $controllerObjClassName();
        // 调用控制器的$action_name方法
        $action_name = ACTION;
        $controllerObj -> $action_name();
    }
}